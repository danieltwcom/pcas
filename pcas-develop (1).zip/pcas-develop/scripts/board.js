$(document).ready(function(){
    $("#nav_bar").load("inc/nav_bar.html");
});
