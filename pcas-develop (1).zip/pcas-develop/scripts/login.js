$(document).ready(function() {
    $('#registration-button').on('click', function() {
        location.href = '/register';
    });
})